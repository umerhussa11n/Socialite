	<div class="form-group">
          {{ Form::label('title', 'Library Title') }}
          {{ Form::text('title',null,array('required','autofocus','class'=>'form-control')) }}
          @if ($errors->has('title'))
          <span class="alert-danger">
              <strong>{{ $errors->first('title') }}</strong>
          </span>
          @endif
    </div>
    <div class="form-group">
          
          {{ Form::checkbox('is_one_time',null,false) }}
          {{ Form::label('is_one_time', 'is one time') }}

    </div>

    {{ Form::submit('Save',array('class'=>'btn btn-sm btn-primary')) }}
            
    {{ Form::button('Cancel',array('class'=>'btn btn-sm btn-danger', 'onclick' => 'history.go(-1)')) }}