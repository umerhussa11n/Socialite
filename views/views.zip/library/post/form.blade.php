	<div class="form-group">
          {{ Form::label('social_media', 'Social Media') }}
          {{ Form::text('social_media',null,array('required','autofocus','class'=>'form-control')) }}
          @if ($errors->has('social_media'))
          <span class="alert-danger">
              <strong>{{ $errors->first('social_media') }}</strong>
          </span>
          @endif
  </div>
  <div class="form-group">
          {{ Form::label('type', 'Type') }}
          {{ Form::text('type',null,array('required','autofocus','class'=>'form-control')) }}
          @if ($errors->has('type'))
          <span class="alert-danger">
              <strong>{{ $errors->first('type') }}</strong>
          </span>
          @endif
  </div>
   <div class="form-group">
          {{ Form::label('message', 'Message') }}
          {{ Form::textarea('message',null,array('required','autofocus','class'=>'form-control')) }}
          @if ($errors->has('message'))
          <span class="alert-danger">
              <strong>{{ $errors->first('message') }}</strong>
          </span>
          @endif
  </div>
  <div class="form-group">
          {{ Form::label('media_url', 'Media URL') }}
          {{ Form::text('media_url',null,array('required','autofocus','class'=>'form-control')) }}
          @if ($errors->has('media_url'))
          <span class="alert-danger">
              <strong>{{ $errors->first('media_url') }}</strong>
          </span>
          @endif
  </div>

  
 

    {{ Form::submit('Save',array('class'=>'btn btn-sm btn-primary')) }}
            
    {{ Form::button('Cancel',array('class'=>'btn btn-sm btn-danger', 'onclick' => 'history.go(-1)')) }}