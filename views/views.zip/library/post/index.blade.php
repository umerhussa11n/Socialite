@extends('app')

@section('title', 'Post List')


@if(Session::has('success'))
	<div class="alert-box success">
		<h2>{{ Session::get('success') }}</h2>
	</div>
@endif

@section('main_content')
	<div class ="row">
		<div class="col-md-12 btn-row">
			<a href="{{url('library/'.$lid.'/post/create')}}" class="btn btn-primary">Add post</a>
		</div>
	</div><!-- /.row -->
	<div class="box box-block bg-white">
		<div class="row">
			<div class="col-md-12">
				@include('message')
				
					<div class="row">
						<div class="col-md-3">
								<div class="card">
									<h5 class="card-header">Library Title</h5>
									<div class="card-body">
										<p>
											<strong>Posts: </strong> 7
										</p>
									</div>
								</div>
						</div>
						<div class="col-md-9">

							@foreach($post as $pk=>$pv)
								<div class="post-excerpt">
									@if($pv->type == 'video')
										<div class="media-left responsive-video">
											<iframe width="250" height="160" src="{{$pv->media_url}}" frameborder="0" allowfullscreen></iframe>
										</div>
									@else
										<div class="media-left">
											<img src="{{$pv->media_url}}" alt="...">
										</div>
									@endif
									
									<div class="media-body">
										<div class="dropdown pull-right dropdown-bars">
											<button class="btn btn-primary" type="button" data-toggle="dropdown"><i class="fa fa-bars" aria-hidden="true"></i></button>
												<ul class="dropdown-menu menu-edited">
													<li><a href="{{url('library/'.$lid.'/post/'.$pv->id.'/edit')}}">Edit</a></li>

													<li><a href="#">Delete</a></li>
												</ul>
										</div>
										<p>
											{{$pv->message}}
										</p>
									</div>
								</div>
							@endforeach
							
						</div>
					</div>


			</div>
		</div>
	</div>
@endsection