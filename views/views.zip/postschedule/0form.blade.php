	 <div class="form-group">
        {{ Form::label('library_id', 'Library Title') }}
        {{ Form::select('library_id',$library,null,array('required','autofocus','class'=>'form-control')) }}
        @if ($errors->has('library_id'))
        <span class="alert-danger">
          <strong>{{ $errors->first('library_id') }}</strong>
        </span>
        @endif
  </div>

     <div class="form-group">
        {{ Form::label('frequency', 'Frequency') }}
        {{ Form::select('frequency', array('d' => 'Daily', 'w' => 'Weekly','m' => 'Monthly'),null,array('required','autofocus','class'=>'form-control')) }}
        @if ($errors->has('frequency'))
        <span class="alert-danger">
          <strong>{{ $errors->first('frequency') }}</strong>
        </span>
        @endif
  </div>


 <div class="form-group" style="display: none;">
        {{ Form::label('days', 'Week Days') }}
        {{ Form::select('days', array(''=>'-- Select A Week Day --','sun' => 'Sunday', 'mon' => 'Monday','tue' => 'Tuesday','wed' => 'Wednesday','thu' => 'Thursday','fri' => 'Friday','sat' => 'Saturday',),null,array('class'=>'form-control')) }}
        @if ($errors->has('days'))
        <span class="alert-danger">
          <strong>{{ $errors->first('days') }}</strong>
        </span>
        @endif
  </div>


 <div class="form-group" style="display: none;">
        {{ Form::label('day', 'Day') }}
        {{ Form::select('day',array('' => '-- Select A Day --') + range(1,31),null,array('class'=>'form-control')) }}
        @if ($errors->has('day'))
        <span class="alert-danger">
          <strong>{{ $errors->first('day') }}</strong>
        </span>
        @endif
  </div>

<div class="form-group">
        {{ Form::label('time', 'Time') }}
        {{ Form::text('time',null,array('required','autofocus','class'=>'form-control ui-timepicker-input')) }}
        @if ($errors->has('time'))
        <span class="alert-danger">
          <strong>{{ $errors->first('time') }}</strong>
        </span>
        @endif
  </div>

    <div class="form-group">
          {{ Form::checkbox('social_media_flag[]','F',false) }}
          {{ Form::label('f', 'Facebook') }}
          &nbsp;&nbsp;
          {{ Form::checkbox('social_media_flag[]','T',false) }}
          {{ Form::label('t', 'Twitter') }}
          &nbsp;&nbsp;
          {{ Form::checkbox('social_media_flag[]','I',false) }}
          {{ Form::label('i', 'Instagram') }}
    </div>

   

    {{ Form::submit('Save',array('class'=>'btn btn-sm btn-primary')) }}
            
    {{ Form::button('Cancel',array('class'=>'btn btn-sm btn-danger', 'onclick' => 'history.go(-1)')) }}


    