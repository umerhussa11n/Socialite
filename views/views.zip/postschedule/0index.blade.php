@extends('app')

@section('title', 'Post List')


@if(Session::has('success'))
	<div class="alert-box success">
		<h2>{{ Session::get('success') }}</h2>
	</div>
@endif

@section('main_content')
	<div class ="row">
		<div class="col-md-12 btn-row">
			<a href="#" class="btn btn-primary">Add </a>
		</div>
	</div><!-- /.row -->
	<div class="box box-block bg-white">
		<div class="row">
			<div class="col-md-4">
				<div class="card">
					<div class="card-header">
						<h5>Add Timeslots</h5>
					</div>
					<div class="card-body">
						{{Form::open(array('url'=>'postschedule','method'=>'POST','class' => 'form'))}}
								@include('postschedule.form')
						{{ Form::close() }}
					</div>
				</div>
			</div>
			<div class="col-md-8">
				@include('message')
				
					<!-- table starts -->

					<table id="calendar">
						<caption>Facebook</caption>
						<tr class="weekdays">
							<th scope="col">Sunday</th>
							<th scope="col">Monday</th>
							<th scope="col">Tuesday</th>
							<th scope="col">Wednesday</th>
							<th scope="col">Thursday</th>
							<th scope="col">Friday</th>
							<th scope="col">Saturday</th>
						</tr>

						<tr class="days">
							
							<td class="day">
								<div class="short-day">Sun</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>

							<td class="day">
								<div class="short-day">Mon</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>

							<td class="day">
								<div class="short-day">Tue</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>

							<td class="day">
								<div class="short-day">Wed</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>

							<td class="day">
								<div class="short-day">Thu</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>

							<td class="day">
								<div class="short-day">Fri</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>

							<td class="day">
								<div class="short-day">Sat</div>
								<div class="event">
									<div class="event-desc">
										HTML 5 lecture with Brad Traversy from Eduonix
									</div>
									<div class="event-time">
										1:00pm to 3:00pm
									</div>
								</div>
							</td>
							
						</tr>


						</table>


					<!-- table ends -->

					@include('postschedule.monthtable')
			</div>
		</div>
	</div>
@endsection