<div class="form-group">
        {{ Form::label('library_id', 'Library Title') }}
        {{ Form::select('library_id',$library,null,array('required','autofocus','class'=>'form-control')) }}
        @if ($errors->has('library_id'))
        <span class="alert-danger">
          <strong>{{ $errors->first('library_id') }}</strong>
        </span>
        @endif
  </div>

     <div class="form-group">
        {{ Form::label('frequency', 'Frequency') }}
        {{ Form::select('frequency', array('d' => 'Daily', 'w' => 'Weekly','m' => 'Monthly'),null,array('required','autofocus','class'=>'form-control')) }}
        @if ($errors->has('frequency'))
        <span class="alert-danger">
          <strong>{{ $errors->first('frequency') }}</strong>
        </span>
        @endif
  </div>


 <div class="form-group" style="display: none;">
        {{ Form::label('days', 'Week Days') }}
        {{ Form::select('days', array('sun' => 'Sunday', 'mon' => 'Monday','tue' => 'Tuesday','wed' => 'Wednesday','thu' => 'Thursday','fri' => 'Friday','sat' => 'Saturday',),null,array('class'=>'form-control')) }}
        @if ($errors->has('days'))
        <span class="alert-danger">
          <strong>{{ $errors->first('days') }}</strong>
        </span>
        @endif
  </div>


 <div class="form-group" style="display: none;">
        {{ Form::label('day', 'Day') }}
        {{ Form::select('day', range(1,31),null,array('class'=>'form-control')) }}
        @if ($errors->has('day'))
        <span class="alert-danger">
          <strong>{{ $errors->first('day') }}</strong>
        </span>
        @endif
  </div>

<div class="form-group">
        {{ Form::label('time', 'Time') }}
        <select class="form-control" id="time" name="time"><?php echo get_times(); ?></select>
  </div>

<div class="form-group">
          {{ Form::checkbox('social_media_flag[]','F',false) }}
          {{ Form::label('f', 'Facebook') }}
          &nbsp;&nbsp;
          {{ Form::checkbox('social_media_flag[]','T',false) }}
          {{ Form::label('t', 'Twitter') }}
          &nbsp;&nbsp;
          {{ Form::checkbox('social_media_flag[]','I',false) }}
          {{ Form::label('i', 'Instagram') }}
    </div>



    {{ Form::submit('Save',array('class'=>'btn btn-sm btn-primary')) }}
            
    {{ Form::button('Cancel',array('class'=>'btn btn-sm btn-danger', 'onclick' => 'history.go(-1)')) }}
    
    
    {{ Form::button('TEST',array('class'=>'btn btn-sm btn-danger', 'onclick' => 'populateCalendar();')) }}


<?php

function get_times( $default = '19:00', $interval = '+15 minutes' ) {

    $output = '';

    $current = strtotime( '00:00' );
    $end = strtotime( '23:59' );

    while( $current <= $end ) {
        $time = date( 'H:i', $current );
        $sel = ( $time == $default ) ? ' selected' : '';

        $output .= "<option value=\"{$time}\"{$sel}>" . date( 'h.i A', $current ) .'</option>';
        $current = strtotime( $interval, $current );
    }

    return $output;
}

?>