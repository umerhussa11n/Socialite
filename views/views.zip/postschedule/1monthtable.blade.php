<table id="calendar_monthly" class="calendar_monthly calendar monthly_calendar" style="display: none;">
            <caption>Monthly</caption>
            <tr class="days">
                    <?php
                    for($i = 1; $i <= 31 ; $i++)
                    {
                    ?>
                    <td class="day d_<?php echo $i; ?>">
                        <div class="month-day"><?php echo $i; ?></div>
                    </td>
                    <?php
                    }
                    ?>


            </tr>
</table>